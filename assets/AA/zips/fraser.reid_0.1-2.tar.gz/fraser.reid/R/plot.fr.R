## file fraser.reid/R/plot.fr.R, v 0.1-2 2009/10/01
##
##  Copyright (C) 2007-2009 Anthony C. Davison 
##
##  This file is part of the "fraser.reid" package for R.  This program 
##  is free software; you can redistribute it and/or modify it under the 
##  terms of the GNU General Public License as published by the Free 
##  Software Foundation; either version 2 of the License, or (at your 
##  option) any later version.
##
##  This library is distributed in the hope that it will be useful,
##  but WITHOUT ANY WARRANTY; without even the implied warranty of
##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program; if not, write to the Free Software
##  Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
##  MA 02111-1307 USA or look up the web page 
##  http://www.gnu.org/copyleft/gpl.html.
##
##  Please send any comments, suggestions or errors found to:
##  Anthony C. Davison, IMA-FSB-EPFL, Station 8, CH-1015 Lausanne, 
##  Switzerland.  Email: Anthony.Davison@epfl.ch.  
##  Web: http://statwww.epfl.ch/davison/davison.html.

plot.fr <- function(x, psi=NULL, all=FALSE, xl="Interest parameter", ...){ # plot a fraser-reid object  old.pars <- par()  if(all) par(mfrow=c(2,2), pty="s") else par(mfrow=c(1,2), pty="s") # top left: plot of pivot as a function of psi  fr <- x
  plot(fr$psi,fr$r,type="l",xlab=xl,ylab="Value of pivot",ylim=c(-4, 4), 
       panel.first=abline(h=qnorm(c(0.005,0.025,0.05,0.5,0.95,0.975,0.995)),col="grey",lwd=0.7))  lines(fr$psi,(fr$normal[1]-fr$psi)/fr$normal[2],col="green")  lines(fr$psi,fr$q,col="red")  lines(fr$psi,fr$r)  lines(fr$psi,fr$rstar,col="blue")#  abline(h=qnorm(c(0.005,0.025,0.05,0,0.95,0.975,0.995)),lty=2)
  legend(sum(fr$normal),4,c("Wald pivot","Likelihood root","Modified root","q(psi)"),
         lty=c(1,1,1,1),col=c("green","black","blue","red"),bty="n")# top right: log likelihood (and adjusted version, I think?) as a function of psi  plot(fr$psi,-fr$r^2/2,type="l",xlab=xl,ylab="Log likelihood",ylim=c(-8, 0),
       panel.first=abline(h=-qchisq(c(0.95,0.99),df=1)/2,col="grey"),lwd=0.7)  lines(fr$psi,-fr$rstar^2/2,col="blue")
  legend(fr$normal[1],-7,c("Profile log likelihood","Modified profile log likelihood"),
         lty=c(1,1),col=c("black","blue"),bty="n")    corr <- log(fr$q/fr$r)/fr$r
  
# optional: add diagnostic panels

  if (all) {  
  # lower left: plot of Phi(pivot) as a function of psi  plot(fr$psi,pnorm(fr$r),type="l",xlab=xl,ylab="Significance function",ylim=c(0,1),
       panel.first=abline(h=c(0.025,0.05,0.5,0.95,0.975),col="grey",lwd=0.7))  lines(fr$psi,pnorm(fr$q),col="red")  lines(fr$psi,pnorm(fr$rstar),col="blue")  legend(sum(fr$normal),0.9,c("Likelihood root","Modified root","q(psi)"),
         lty=c(1,1,1),col=c("black","blue","red"),bty="n")# lower right: log(q/r)/r as a function of r (should be smooth)  plot(fr$r,corr,type="l",xlab="Likelihood root r",ylab="Correction log(q/r)/r",
       panel.first={ abline(h=0,col="grey"); abline(v=0,col="grey")})  points(fr$r,log(fr$q/fr$r)/fr$r)#  lines(fr$r,fitted(lm(corr~poly(fr$r,7))),col="green")#  lines(smooth.spline(fr$r,corr))
  
  }
    par(old.pars)# computation of significance probability if psi is specified  if (!is.null(psi)) {  fit.r <- smooth.spline(fr$psi, fr$r)  fit.rstar <- smooth.spline(fr$psi, fr$rstar)  p.r <- predict(fit.r, psi)  p.rstar <- predict(fit.rstar, psi)  z <- c((fr$normal[1]-psi)/fr$normal[2],p.r$y,p.rstar$y)  cat("z, r, r*   :",z,"\n")  cat("Sig. levels:",pnorm(z),"\n") }}
