.First.lib <- function(libname, pkgname) 
{
  version <- as.character("0.1-2 (2009/10/01)")
  cat("\n   Package \"fraser.reid\"", version, "\n")
  cat("   Copyright (C) 2007-2009 A. C. Davison \n\n")
  cat("Computes Fraser-Reid approximation for higher order asymptotics,\n")
  cat("and accompanies the book Applied Asymptotics: Case Studies in\n") 
  cat("Small-Sample Statistics (Brazzale, Davison & Reid, 2007, Cambridge\n") 
  cat("University Press).  More details can be found at\n") 
  cat("http://statwww.epfl.ch/AA.\n")
  invisible()
}
