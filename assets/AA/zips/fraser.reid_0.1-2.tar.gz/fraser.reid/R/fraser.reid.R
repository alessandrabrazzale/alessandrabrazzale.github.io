## file fraser.reid/R/fraser.reid.R, v 0.1-2 2009/10/01
##
##  Copyright (C) 2007-2009 Anthony C. Davison 
##
##  This file is part of the "fraser.reid" package for R.  This program 
##  is free software; you can redistribute it and/or modify it under the 
##  terms of the GNU General Public License as published by the Free 
##  Software Foundation; either version 2 of the License, or (at your 
##  option) any later version.
##
##  This library is distributed in the hope that it will be useful,
##  but WITHOUT ANY WARRANTY; without even the implied warranty of
##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program; if not, write to the Free Software
##  Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
##  MA 02111-1307 USA or look up the web page 
##  http://www.gnu.org/copyleft/gpl.html.
##
##  Please send any comments, suggestions or errors found to:
##  Anthony C. Davison, IMA-FSB-EPFL, Station 8, CH-1015 Lausanne, 
##  Switzerland.  Email: Anthony.Davison@epfl.ch.  
##  Web: http://statwww.epfl.ch/davison/davison.html.

fraser.reid <- function(psi=NULL, nlogL, phi, make.V, th.init, d, tol=10^(-5), n.psi=50)
{
#
# define some ancillary functions
#
even <- function(n) (2*floor(n/2)==n)
#
d.phi <- function(x, V, d, tol=tol)
  {  # numerical differentiation of function phi at x
    f0 <- phi(x, V, d)
    p <- length(f0)
    out <- matrix(NA,p,p)
    for (i in 1:p) 
  {  x1 <- x
     x1[i] <- x1[i]+tol
     out[i,] <- (phi(x1, V, d)-f0)/tol }
# dxd matrix with columns for elements of phi and rows for elements of theta
# first row corresponds to psi, rest to lambda
    out
  }
#
  nlogL.full <- function(th, d)  nlogL(th[1], th[-1], d)
  nlogL.rest <- function(lam, psi, d)  nlogL(psi, lam, d)
#
# full maximum likelihood fit 
#
  full <- nlm(nlogL.full, jitter(th.init), hessian=TRUE, d=d)
  if(full$code>2) stop("Full fit failed: try different initial values")
  th.full <- full$estimate
  th.se <- sqrt(diag(solve(full$hessian)))
  psi.se <- th.se[1]
  L.full <- -full$minimum
  out <- NULL
  out$normal <- c(th.full[1],psi.se)
  out$th.hat <- th.full
  out$th.hat.se <- th.se
# 
# compute matrix of Vs for later computation of local parametrization
#
  V <- make.V(th.full, d)
#
# choose a range of psi or use those given
#
  if(is.null(psi)) psi <- seq(from=th.full[1]-5*psi.se,to=th.full[1]+5*psi.se,length=n.psi)
#
# restricted maximum likelihood fits
#
  K <- ceiling(n.psi/2)
  if(even(n.psi)) K <- K+1
  n.psi <- length(psi)
  L.rest <- J.rest <- psi
  out$th.rest <- matrix(th.full,n.psi,length(th.full),byrow=TRUE)
  if(n.psi>2)
{ 
  for(j in (K-1):1)
  {
    rest <- nlm(nlogL.rest, jitter(out$th.rest[j+1,-1]), hessian=TRUE, psi=psi[j], d=d)
    out$th.rest[j,] <- c(psi[j],rest$estimate)
    L.rest[j] <- -rest$minimum
    J.rest[j] <- det(rest$hessian)
  }
  if(even(n.psi))
  { 
  	rest <- nlm(nlogL.rest, jitter(th.full[-1]), hessian=TRUE, psi=psi[K], d=d)
    out$th.rest[K,] <- c(psi[K],rest$estimate)
    L.rest[K] <- -rest$minimum
    J.rest[K] <- det(rest$hessian)
  }
  for(j in (K+1):n.psi)
  {
    rest <- nlm(nlogL.rest, jitter(out$th.rest[j-1,-1]), hessian=TRUE, psi=psi[j], d=d)
    out$th.rest[j,] <- c(psi[j],rest$estimate)
    L.rest[j] <- -rest$minimum
    J.rest[j] <- det(rest$hessian)
  }
}
#
# compute r
#
  out$r <- sign(out$normal[1]-out$th.rest[,1])*sqrt(2*(L.full-L.rest))
#
# compute q, first doing computations at full MLE
#
  dphi.dth.full <- d.phi(th.full, V, d, tol)
  D.bot <- det(dphi.dth.full)
  j.th.th <- det(full$hessian)
#
# prepare output
#
  out$q <- out$psi <- psi
#
  for (j in 1:n.psi)
{
  dphi.dth.rest <- d.phi(out$th.rest[j,], V, d, tol)
  dphi.dth.rest[1,] <- phi(out$th.hat, V, d) - phi(out$th.rest[j,],V,d)
  D.top <- det(dphi.dth.rest)
  j.lam.lam <- J.rest[j]
  out$q[j] <- (D.top/D.bot)*sqrt(j.th.th/j.lam.lam)
}
#
# output
#
  out$rstar <- out$r + log(out$q/out$r)/out$r
  class(out) <- "fr"
  out
}
