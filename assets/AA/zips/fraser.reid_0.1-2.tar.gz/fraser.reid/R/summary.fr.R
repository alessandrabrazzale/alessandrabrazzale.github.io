## file fraser.reid/R/summary.fr.R, v 0.1-2 2009/10/01
##
##  Copyright (C) 2007-2009 Anthony C. Davison 
##
##  This file is part of the "fraser.reid" package for R.  This program 
##  is free software; you can redistribute it and/or modify it under the 
##  terms of the GNU General Public License as published by the Free 
##  Software Foundation; either version 2 of the License, or (at your 
##  option) any later version.
##
##  This library is distributed in the hope that it will be useful,
##  but WITHOUT ANY WARRANTY; without even the implied warranty of
##  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program; if not, write to the Free Software
##  Foundation, Inc., 59 Temple Place, Suite 330, Boston, 
##  MA 02111-1307 USA or look up the web page 
##  http://www.gnu.org/copyleft/gpl.html.
##
##  Please send any comments, suggestions or errors found to:
##  Anthony C. Davison, IMA-FSB-EPFL, Station 8, CH-1015 Lausanne, 
##  Switzerland.  Email: Anthony.Davison@epfl.ch.  
##  Web: http://statwww.epfl.ch/davison/davison.html.

lik.ci <- function(object, conf=c(0.975,0.025), ...){  # read likelihood confidence interval off from fraser-reid object
  fr <- object
  fit.r <- smooth.spline(fr$r, fr$psi)  fit.rstar <- smooth.spline(fr$rstar, fr$psi)  p.r <- predict(fit.r, qnorm(conf))  p.rstar <- predict(fit.rstar, qnorm(conf))  mle.hoa <- predict(fit.rstar, 0)  se.hoa <- predict(fit.rstar, 0, deriv=1)  mle.hoa <- c(mle.hoa$y, -se.hoa$y)  z.lims <- fr$normal[1]-qnorm(conf)*fr$normal[2]  r.lims <- p.r$y  rstar.lims <- p.rstar$y  cat("Confidence intervals, levels:", 1-conf,"\n")  cat("Wald statistic, z           :", z.lims,"\n")  cat("Likelihood root, r          :", r.lims,"\n")  cat("Modified likelihood root, r*:", rstar.lims,"\n")  invisible(list(mle=fr$normal, mle.hoa=mle.hoa, z.lims=z.lims, 
                 r.lims=r.lims, rstar.lims=rstar.lims))}summary.fr <- lik.ci
