.First.lib <- function(libname, pkgname) 
{
  version <- as.character("0.1-0 (2009/10/01)")
  cat("\n   Package \"AA\"", version, "\n")
  cat("   Copyright (C) 2007-2009 A.R. Brazzale, A.C. Davison & N. Reid\n\n")
  cat("This package contains the datasets for use with the examples\n")
  cat("and practicals of the book 'Applied Asymptotics: Case Studies in\n") 
  cat("Small-Sample Statistics' by Brazzale, Davison, and Reid (2007, CUP).\n") 
  cat("The practicals themselves can be found at http://statwww.epfl.ch/AA.\n")
  invisible()
}
