### Name: risk
### Title: Survival of Multiple Myeloma Patients
### Aliases: risk
### Keywords: datasets

### ** Examples

data(risk)
attach(risk)
boxplot(y1/n1, y2/n2, xlab = "treatment method", ylab = "proportion of survival")
detach()



