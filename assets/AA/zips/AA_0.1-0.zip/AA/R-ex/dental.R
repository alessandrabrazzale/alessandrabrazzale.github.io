### Name: dental
### Title: Data on Dental Status of Children
### Aliases: dental
### Keywords: datasets

### ** Examples

data(dental)
barplot(dental$frequency)



