### Name: voltage
### Title: Test Results of Voltage Regulators for Automobiles
### Aliases: voltage
### Keywords: datasets

### ** Examples

data(voltage)
par(mfrow = c(1,3))
boxplot(y ~ Set, data = voltage, main="setting station")
boxplot(y ~ Test, data = voltage, main="testing station")
boxplot(y ~ Reg, data = voltage, main="regulator number")



