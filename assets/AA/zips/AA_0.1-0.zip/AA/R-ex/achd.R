### Name: achd
### Title: Age and Coronary Heart Disease Data
### Aliases: achd
### Keywords: datasets

### ** Examples

data(achd)
plot(disease ~ age, data = achd)
plot(age ~ factor(disease), data = achd)



