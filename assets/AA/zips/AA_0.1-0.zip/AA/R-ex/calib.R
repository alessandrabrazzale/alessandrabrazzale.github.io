### Name: calib
### Title: Blood Plasma Data
### Aliases: calib
### Keywords: datasets

### ** Examples

data(calib)
plot(x ~ y, data = calib)
mod <- lm(x ~ y, data = calib)
abline(mod)



