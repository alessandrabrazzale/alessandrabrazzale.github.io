### Name: cost
### Title: Cost Data
### Aliases: cost
### Keywords: datasets

### ** Examples

data(cost)
plot(y ~ factor(f), data = cost, xlab = "therapy", ylab = "cost of therapy")



