### Name: leuk
### Title: Survival Times and White Blood Cell Counts
### Aliases: leuk
### Keywords: datasets

### ** Examples

data(leuk)
plot(t ~ x, data = leuk, xlab = "white blood cell counts", 
     ylab = "survival time")



