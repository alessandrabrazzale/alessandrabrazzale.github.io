### Name: aircondit
### Title: Failure Times for Air-Conditioning Units
### Aliases: aircondit
### Keywords: datasets

### ** Examples

data(aircondit)
plot(time ~ factor(number), data = aircondit, xlab = "aircraft", 
     ylab = "failure time")



