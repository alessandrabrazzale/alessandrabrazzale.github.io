### Name: boothb
### Title: Data on Responses to Analgesic
### Aliases: boothb
### Keywords: datasets

### ** Examples

data(boothb)
plot(y ~ factor(Group), data = boothb, xlab = "group", 
     ylab = "differences in pain response")



