### Name: reactor
### Title: Measured and Theoretical Temperatures of a Chemical Reactor
### Aliases: reactor
### Keywords: datasets

### ** Examples

data(reactor)
plot(measured ~ theoretical, data = reactor, xlim = c(400, 520),
     ylim = c(400, 520))
abline(0, 1)



