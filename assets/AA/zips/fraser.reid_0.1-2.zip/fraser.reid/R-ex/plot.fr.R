### Name: plot.fr
### Title: Plot a Fraser-Reid Object
### Aliases: plot.fr
### Keywords: models htest

### ** Examples

## See the examples to fraser.reid.



