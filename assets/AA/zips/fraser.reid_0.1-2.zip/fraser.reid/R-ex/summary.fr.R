### Name: summary.fr
### Title: Likelihood-Based Confidence Intervals Based on Fraser-Reid
###   Object
### Aliases: summary.fr lik.ci
### Keywords: models htest

### ** Examples

## See the examples to fraser.reid.



